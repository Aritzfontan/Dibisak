package gui;

/**
 * @author Software Engineering teachers
 */


import javax.swing.*;


import businessLogic.BLFacade;

import java.awt.Color;
import java.awt.Font;


public class MainGUI extends JFrame {
	
	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;
	private JButton jButtonSell;
	private JButton jButtonBuy;
	private JButton jButtonIdentify;

    private static BLFacade appFacadeInterface;
	
	public static BLFacade getBusinessLogic(){
		return appFacadeInterface;
	}
	 
	public static void setBussinessLogic (BLFacade afi){
		appFacadeInterface=afi;
	}
	protected JLabel jLabelSelectOption;

	/**
	 * This is the default constructor
	 */
	public MainGUI() {
		super();

		
		// this.setSize(271, 295);
		this.setSize(495, 290);
		jLabelSelectOption = new JLabel("Aukeratu");
		jLabelSelectOption.setBounds(116, 10, 245, 43);
		jLabelSelectOption.setFont(new Font("Tahoma", Font.BOLD, 13));
		jLabelSelectOption.setForeground(Color.BLACK);
		jLabelSelectOption.setHorizontalAlignment(SwingConstants.CENTER);
		
		jButtonSell = new JButton();
		jButtonSell.setBounds(100, 104, 272, 38);
		jButtonSell.setText("Dibisak saldu");
		jButtonSell.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent e) {
				JFrame a = new SellCurrencyGUI();
				a.setVisible(true);
			}
		});
		
		jButtonIdentify = new JButton();
		jButtonIdentify.setBounds(100, 146, 272, 38);
		jButtonIdentify.setText("Bezeroa identifikatu");
		jButtonIdentify.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent e) {
				JFrame a = new IdentifyCustomerGUI();
				a.setVisible(true);
			}
		});
		
		jContentPane = new JPanel();
		jContentPane.setLayout(null);
		jContentPane.add(jLabelSelectOption);
		jContentPane.add(jButtonSell);
		jContentPane.add(jButtonIdentify);
		
		
		setContentPane(jContentPane);
			
			jButtonBuy = new JButton();
			jButtonBuy.setBounds(100, 63, 272, 38);
			jButtonBuy.setText("Dibisak erosi");
			jButtonBuy.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					JFrame a = new BuyCurrencyGUI();

					a.setVisible(true);
				}
			});
			jContentPane.add(jButtonBuy);
			

	}
	
	
} // @jve:decl-index=0:visual-constraint="0,0"

