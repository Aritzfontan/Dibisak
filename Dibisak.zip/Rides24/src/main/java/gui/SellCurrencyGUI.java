package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import businessLogic.BLFacade;
import domain.Dibisa;
import domain.Kontua;
import domain.Sukurtsala;
import domain.SukurtsalekoDibisa;

public class SellCurrencyGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField naField;
	private JTextField dibisaKop;
	private JLabel naLabel;
	private JLabel kontuLabel;
	private JLabel dibLabel;
	private JLabel sukLabel;
	private JLabel kopuruLabel;
	
	private JComboBox<Kontua> kontuComboBox;
	private JComboBox<Dibisa> dibComboBox;
	private JComboBox<Sukurtsala> sukComboBox;
	private DefaultComboBoxModel<Kontua> kontuak = new DefaultComboBoxModel<Kontua>();
	private DefaultComboBoxModel<Dibisa> dibisak= new DefaultComboBoxModel<Dibisa>();
	private DefaultComboBoxModel<Sukurtsala> sukurtsalak = new DefaultComboBoxModel<Sukurtsala>();
	
	private JButton btnErosi;
	private JTextArea emaitzaText;
	
	private Kontua k;
	private Dibisa dib;
	private Sukurtsala suk;
	private SukurtsalekoDibisa sukD;
		
	private double kopurua;
	private boolean b = false;
	private double hasierako_saldo;
	private double bukaerako_saldo;


	/**
	 * Create the frame.
	 */
	public SellCurrencyGUI() {
		BLFacade facade = MainGUI.getBusinessLogic();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		naLabel = new JLabel("Sartu NA:");
		naLabel.setBounds(30, 13, 45, 13);
		contentPane.add(naLabel);
		
		JTextArea saldoArea = new JTextArea();
		saldoArea.setEditable(false);
		saldoArea.setBounds(201, 125, 87, 22);
		contentPane.add(saldoArea);
		
		naField = new JTextField();
		naField.setBounds(85, 10, 96, 19);
		contentPane.add(naField);
		naField.setColumns(10);
		naField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				String nan = naField.getText();
				kontuak.removeAllElements();
				kontuak.addAll(facade.getAccountsByNa(nan));
				if(kontuak.getSize() > 0) {
					kontuComboBox.setSelectedIndex(-1);
				}
				kontuComboBox.setSelectedIndex(-1);
			}
		});
		
		kontuLabel = new JLabel("Aukeratu kontua:");
		kontuLabel.setBounds(191, 13, 87, 13);
		contentPane.add(kontuLabel);
		
		kontuComboBox = new JComboBox<Kontua>();
		kontuComboBox.setBounds(276, 10, 135, 19);
		contentPane.add(kontuComboBox);
		kontuComboBox.setModel(kontuak);
		kontuComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				k = (Kontua)kontuComboBox.getSelectedItem();
				if(kontuComboBox.getSelectedItem() != null) {
					hasierako_saldo = k.getSaldoa();
					saldoArea.setText(Double.toString(hasierako_saldo));
				}
				saltzekoBotoiaAktibatu();
			}
		});
		
		dibLabel = new JLabel("Aukeratu dibisa:");
		dibLabel.setBounds(30, 60, 87, 13);
		contentPane.add(dibLabel);
		
		dibComboBox = new JComboBox<Dibisa>();
		dibComboBox.setBounds(141, 56, 270, 21);
		contentPane.add(dibComboBox);
		dibComboBox.setModel(dibisak);
		dibisak.addAll(facade.getAllCurrencies());
		dibComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dib = (Dibisa) dibComboBox.getSelectedItem();
				
				saltzekoBotoiaAktibatu();
			}
		});
		
		sukLabel = new JLabel("Aukeratu sukurtsala:");
		sukLabel.setBounds(30, 95, 103, 13);
		contentPane.add(sukLabel);
		
		sukComboBox = new JComboBox<Sukurtsala>();
		sukComboBox.setBounds(162, 91, 249, 21);
		contentPane.add(sukComboBox);
		sukComboBox.setModel(sukurtsalak);
		sukurtsalak.addAll(facade.getAllBranches());
		sukComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				suk = (Sukurtsala) sukComboBox.getSelectedItem();
				saltzekoBotoiaAktibatu();
			}
		});
		
		kopuruLabel = new JLabel("Sartu saldu nahi den kopurua:");
		kopuruLabel.setBounds(30, 165, 165, 13);
		contentPane.add(kopuruLabel);
		
		
		
		dibisaKop = new JTextField();
		dibisaKop.setBounds(216, 162, 96, 19);
		contentPane.add(dibisaKop);
		dibisaKop.setColumns(10);
		
		btnErosi = new JButton("Erosi");
		btnErosi.setBounds(162, 200, 85, 21);
		contentPane.add(btnErosi);
		btnErosi.setEnabled(false);
		
		emaitzaText = new JTextArea();
		emaitzaText.setBounds(30, 231, 381, 32);
		contentPane.add(emaitzaText);		
		btnErosi.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        emaitzaText.setEnabled(true);
		    	
		        sukD = facade.getSukDibFromDibAndSuk(dib, suk);
		        if (sukD == null) {
		            emaitzaText.setText("Ez dago sukurtsal honek dibisa hau saltzeko aukerarik.");
		            return;
		        }

		        try {
		            kopurua = Double.parseDouble(dibisaKop.getText());
		            if (kopurua <= 0) {
		                emaitzaText.setText("Kopurua positiboa izan behar da.");
		                return;
		            }
		        } catch (NumberFormatException ex) {
		            emaitzaText.setText("Kopurua zenbaki baliozkoa izan behar da.");
		            return;
		        }

		        facade.diruaGehitu(k, kopurua, dib, sukD);
		        b = true;
		        if (b) {
		            bukaerako_saldo = k.getSaldoa();
		            emaitzaText.setText("Dibisak saldu egin dira. Saldo berria: " + bukaerako_saldo);
		        } else {
		            emaitzaText.setText("Ezin izan dira dibisak saldu.");
		        }
		    }
		});
		
		JLabel saldoLabel = new JLabel("Uneko saldoa:");
		saldoLabel.setBounds(54, 131, 103, 13);
		contentPane.add(saldoLabel);
		
	}
	public void saltzekoBotoiaAktibatu() {
		btnErosi.setEnabled(k != null && dib != null && suk != null);
	}

}
