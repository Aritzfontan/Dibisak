package gui;

import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import businessLogic.BLFacade;
import javax.swing.JTextArea;

public class IdentifyCustomerGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel naLabel;
	private JTextField naField;
	private JTextArea textArea;


	public IdentifyCustomerGUI() {
		BLFacade facade = MainGUI.getBusinessLogic();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		naLabel = new JLabel("Sartu NA:");
		naLabel.setBounds(30, 13, 75, 13);
		contentPane.add(naLabel);
		
		naField = new JTextField();
		naField.setBounds(174, 10, 96, 19);
		contentPane.add(naField);
		naField.setColumns(10);
		
		textArea = new JTextArea();
		textArea.setBounds(30, 85, 376, 168);
		contentPane.add(textArea);
		
		JLabel lblNewLabel = new JLabel("(beheko karratuan klik egin NA jarri eta gero\r\n)");
		lblNewLabel.setBounds(53, 52, 303, 13);
		contentPane.add(lblNewLabel);
		
		
		naField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				String nan = naField.getText();
				String izena = facade.getCustomerName(nan);
				String kontuak = facade.getInfoAccounts(nan);
				textArea.setText("Bezeroaren izena: " + izena + "\n" + "Kontuak: " + "\n" + kontuak);
			}
		});
	}
}
