package businessLogic;

import java.util.*;

//import domain.Booking;
import domain.*;


import javax.jws.WebMethod;
import javax.jws.WebService;
 
/**
 * Interface that specifies the business logic.
 */
@WebService
public interface BLFacade  {
	  
	
	public List<Kontua> getAccountsByNa(String na);
	public SukurtsalekoDibisa getSukDibFromDibAndSuk(Dibisa dibisa, Sukurtsala sukurtsala);
	public void diruaGehitu(Kontua k, double zenbat, Dibisa dib, SukurtsalekoDibisa sukD);
	public boolean diruaKendu(Kontua k, double zenbat, Dibisa dib, SukurtsalekoDibisa sukD);
	public List<Sukurtsala> getAllBranches();
	public List<Dibisa> getAllCurrencies();
	public String getInfoAccounts(String na);
	public String getCustomerName(String na);
	
	
	
	
	@WebMethod public void initializeBD();

	
}
