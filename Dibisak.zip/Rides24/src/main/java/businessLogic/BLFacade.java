package businessLogic;

import java.util.*;

import domain.*;

import javax.jws.WebMethod;
import javax.jws.WebService;
 
/**
 * Interface that specifies the business logic.
 */
@WebService
public interface BLFacade  {
	  
	@WebMethod
	public List<Kontua> getAccountsByNa(String na);
	@WebMethod
	public SukurtsalekoDibisa getSukDibFromDibAndSuk(Dibisa dibisa, Sukurtsala sukurtsala);
	@WebMethod
	public void diruaGehitu(Kontua k, double zenbat, Dibisa dib, SukurtsalekoDibisa sukD);
	@WebMethod
	public boolean diruaKendu(Kontua k, double zenbat, Dibisa dib, SukurtsalekoDibisa sukD);
	@WebMethod
	public List<Sukurtsala> getAllBranches();
	@WebMethod
	public List<Dibisa> getAllCurrencies();
	@WebMethod
	public String getInfoAccounts(String na);
	@WebMethod
	public String getCustomerName(String na);
	@WebMethod
	public String getInfoEragiketak(String na);

	
	@WebMethod public void initializeBD();

	
}
