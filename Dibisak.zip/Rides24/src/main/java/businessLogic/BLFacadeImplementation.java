package businessLogic;
import java.util.*;

import javax.jws.WebMethod;
import javax.jws.WebService;

import configuration.ConfigXML;
import dataAccess.DataAccess;
import domain.*;


/**
 * It implements the business logic as a web service.
 */
@WebService(endpointInterface = "businessLogic.BLFacade")
public class BLFacadeImplementation  implements BLFacade {
	DataAccess dbManager;

	public BLFacadeImplementation()  {		
		System.out.println("Creating BLFacadeImplementation instance");
		
		
		    dbManager=new DataAccess();
		    
		//dbManager.close();

		
	}
	
    public BLFacadeImplementation(DataAccess da)  {
		
		System.out.println("Creating BLFacadeImplementation instance with DataAccess parameter");
		ConfigXML c=ConfigXML.getInstance();
		
		dbManager=da;		
	}
    
    @WebMethod
    public List<Kontua> getAccountsByNa(String na){
    	dbManager.open();
    	List<Kontua> lista = dbManager.getAccountsByNa(na);
    	dbManager.close();
    	return lista;
    }
    
    @WebMethod
    public SukurtsalekoDibisa getSukDibFromDibAndSuk(Dibisa dibisa, Sukurtsala sukurtsala) {
    	dbManager.open();
    	SukurtsalekoDibisa sukD = dbManager.getSukDibFromDibAndSuk(dibisa, sukurtsala);
    	dbManager.close();
    	return sukD;
    }
    
    @WebMethod
    public void diruaGehitu(Kontua k, double zenbat, Dibisa dib, SukurtsalekoDibisa sukD) {
    	dbManager.open();
    	dbManager.diruaGehitu(k, zenbat, dib, sukD);
    	dbManager.close();
    }
    
    @WebMethod
	public boolean diruaKendu(Kontua k, double zenbat, Dibisa dib, SukurtsalekoDibisa suk) {
		dbManager.open();
		boolean ema = dbManager.diruaKendu(k, zenbat, dib, suk);
		dbManager.close();
		return ema;
	}
    
    @WebMethod
	public List<Sukurtsala> getAllBranches(){
		dbManager.open();
		List<Sukurtsala> list = dbManager.getAllBranches();
		dbManager.close();
		return list;
	}
    
    @WebMethod
	public List<Dibisa> getAllCurrencies(){
		dbManager.open();
		List<Dibisa> list = dbManager.getAllCurrencies();
		dbManager.close();
		return list;
	}
    
    @WebMethod
	public String getInfoAccounts(String na) {
		dbManager.open();
		String emaitza = dbManager.getInfoAccounts(na);
		dbManager.close();
		return emaitza;
	}
    
    @WebMethod
	public String getCustomerName(String na) {
		dbManager.open();
		String izen = dbManager.getCustomerName(na);
		dbManager.close();
		return izen;
	}
    @WebMethod
    public String getInfoEragiketak(String na) {
    	dbManager.open();
    	String erag = dbManager.getInfoEragiketak(na);
    	dbManager.close();
    	return erag;
    }
    
	/**
	 * {@inheritDoc}
	 */
    @WebMethod	
	 public void initializeBD(){
    	dbManager.open();
		dbManager.initializeDB();
		dbManager.close();
	}

}

