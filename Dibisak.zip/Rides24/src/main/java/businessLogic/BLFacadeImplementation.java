package businessLogic;
import java.util.*;

import javax.jws.WebMethod;
import javax.jws.WebService;

import configuration.ConfigXML;
import dataAccess.DataAccess;
import domain.*;


/**
 * It implements the business logic as a web service.
 */
@WebService(endpointInterface = "businessLogic.BLFacade")
public class BLFacadeImplementation  implements BLFacade {
	DataAccess dbManager;

	public BLFacadeImplementation()  {		
		System.out.println("Creating BLFacadeImplementation instance");
		
		
		    dbManager=new DataAccess();
		    
		//dbManager.close();

		
	}
	
    public BLFacadeImplementation(DataAccess da)  {
		
		System.out.println("Creating BLFacadeImplementation instance with DataAccess parameter");
		ConfigXML c=ConfigXML.getInstance();
		
		dbManager=da;		
	}
    
    
    public List<Kontua> getAccountsByNa(String na){
    	dbManager.open();
    	List<Kontua> lista = dbManager.getAccountsByNa(na);
    	dbManager.close();
    	return lista;
    }
    
    public SukurtsalekoDibisa getSukDibFromDibAndSuk(Dibisa dibisa, Sukurtsala sukurtsala) {
    	dbManager.open();
    	SukurtsalekoDibisa sukD = dbManager.getSukDibFromDibAndSuk(dibisa, sukurtsala);
    	dbManager.close();
    	return sukD;
    }
    
    public void diruaGehitu(Kontua k, double zenbat, Dibisa dib, SukurtsalekoDibisa sukD) {
    	dbManager.open();
    	dbManager.diruaGehitu(k, zenbat, dib, sukD);
    	dbManager.close();
    }
    
	public boolean diruaKendu(Kontua k, double zenbat, Dibisa dib, SukurtsalekoDibisa sukD) {
		dbManager.open();
		boolean ema = dbManager.diruaKendu(k, zenbat, dib, sukD);
		dbManager.close();
		return ema;
	}
	public List<Sukurtsala> getAllBranches(){
		dbManager.open();
		List<Sukurtsala> list = dbManager.getAllBranches();
		dbManager.close();
		return list;
	}
	public List<Dibisa> getAllCurrencies(){
		dbManager.open();
		List<Dibisa> list = dbManager.getAllCurrencies();
		dbManager.close();
		return list;
	}
	public String getInfoAccounts(String na) {
		dbManager.open();
		String emaitza = dbManager.getInfoAccounts(na);
		dbManager.close();
		return emaitza;
	}
	public String getCustomerName(String na) {
		dbManager.open();
		String izen = dbManager.getCustomerName(na);
		dbManager.close();
		return izen;
	}
    

	/**
	 * {@inheritDoc}
	 */
    @WebMethod	
	 public void initializeBD(){
    	dbManager.open();
		dbManager.initializeDB();
		dbManager.close();
	}

}

