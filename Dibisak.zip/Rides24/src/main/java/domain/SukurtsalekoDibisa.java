package domain;
import java.io.Serializable;

import javax.persistence.*;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class SukurtsalekoDibisa implements Serializable{
	private static final long serialVersionUID = 1L;
	private double komisio;
	private double stock;
	
	@XmlIDREF
	@ManyToOne
	private Dibisa dib;
	@XmlIDREF
	@ManyToOne
	private Sukurtsala suk;
	@XmlID
	@Id
	private String id;
	
	public SukurtsalekoDibisa(double komisio, double stock, String id) {
		this.komisio = komisio;
		this.stock = stock;
		this.id = id;
	}
	
	public SukurtsalekoDibisa() {
		super();
	}

	public double getKomisio() {
		return komisio;
	}

	public void setKomisio(double komisio) {
		this.komisio = komisio;
	}

	public double getStock() {
		return stock;
	}

	public void setStock(double stock) {
		this.stock = stock;
	}

	public Dibisa getDib() {
		return dib;
	}

	public void setDib(Dibisa dib) {
		this.dib = dib;
	}

	public Sukurtsala getSuk() {
		return suk;
	}

	public void setSuk(Sukurtsala suk) {
		this.suk = suk;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}