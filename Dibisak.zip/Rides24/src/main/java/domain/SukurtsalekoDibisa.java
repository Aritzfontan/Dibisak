package domain;
import javax.persistence.*;

@Entity
public class SukurtsalekoDibisa {
	private double komisio;
	private double stock;
	
	@ManyToOne
	private Dibisa dib;
	@ManyToOne
	private Sukurtsala suk;
	@Id
	private String id;
	
	public SukurtsalekoDibisa(double komisio, double stock, String id) {
		this.komisio = komisio;
		this.stock = stock;
		this.id = id;
	}

	public double getKomisio() {
		return komisio;
	}

	public void setKomisio(double komisio) {
		this.komisio = komisio;
	}

	public double getStock() {
		return stock;
	}

	public void setStock(double stock) {
		this.stock = stock;
	}

	public Dibisa getDib() {
		return dib;
	}

	public void setDib(Dibisa dib) {
		this.dib = dib;
	}

	public Sukurtsala getSuk() {
		return suk;
	}

	public void setSuk(Sukurtsala suk) {
		this.suk = suk;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	
}