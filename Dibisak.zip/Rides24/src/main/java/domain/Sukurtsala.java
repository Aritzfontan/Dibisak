package domain;
import javax.persistence.*;
import java.util.*;

@Entity
public class Sukurtsala {
	@Id
	private String lekua;
	
	@OneToMany(mappedBy = "suk", cascade = CascadeType.PERSIST)
	private List<SukurtsalekoDibisa> sukDibisak = new Vector<SukurtsalekoDibisa>();
	
	public Sukurtsala(String lekua) {
		this.lekua = lekua;
	}

	public String getLekua() {
		return lekua;
	}

	public void setLekua(String lekua) {
		this.lekua = lekua;
	}

	public List<SukurtsalekoDibisa> getSukDibisak() {
		return sukDibisak;
	}

	public void setSukDibisak(List<SukurtsalekoDibisa> sukDibisak) {
		this.sukDibisak = sukDibisak;
	}

	public void addSukurtsalekoDibisa(SukurtsalekoDibisa sukD) {
		if (!this.sukDibisak.contains(sukD)) {
			this.sukDibisak.add(sukD);
			sukD.setSuk(this);
		}
	}
	public String toString() {
		return this.lekua;
	}
	
}
