package domain;
import javax.persistence.*;

import java.io.Serializable;
import java.util.*;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class Sukurtsala implements Serializable{
	private static final long serialVersionUID = 1L;
	@XmlID
	@Id
	private String lekua;
	
	@OneToMany(mappedBy = "suk", cascade = CascadeType.PERSIST)
	private List<SukurtsalekoDibisa> sukDibisak = new Vector<SukurtsalekoDibisa>();
	
	public Sukurtsala(String lekua) {
		this.lekua = lekua;
	}
	
	public Sukurtsala() {
		super();
	}

	public String getLekua() {
		return lekua;
	}

	public void setLekua(String lekua) {
		this.lekua = lekua;
	}

	public List<SukurtsalekoDibisa> getSukDibisak() {
		return sukDibisak;
	}

	public void setSukDibisak(List<SukurtsalekoDibisa> sukDibisak) {
		this.sukDibisak = sukDibisak;
	}

	public void addSukurtsalekoDibisa(SukurtsalekoDibisa sukD) {
		if (!this.sukDibisak.contains(sukD)) {
			this.sukDibisak.add(sukD);
			sukD.setSuk(this);
		}
	}
	public String toString() {
		return this.lekua;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
