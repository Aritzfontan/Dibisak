package domain;
import javax.persistence.*;

@Entity
public class Eragiketa {
	
	private String mota;
	private double kopurua;
	@Id
	private String dibisa_sukur;
	
	@ManyToOne
	private Kontua kontu;
	
	@ManyToOne
	private Dibisa dib;
	
	public Eragiketa(String mota, double kopurua, String dibsuk) {
		this.mota = mota;
		this.kopurua = kopurua;
		this.dibisa_sukur = dibsuk;
	}

	public String getMota() {
		return mota;
	}

	public void setMota(String mota) {
		this.mota = mota;
	}

	public double getKopurua() {
		return kopurua;
	}

	public void setKopurua(double kopurua) {
		this.kopurua = kopurua;
	}

	public Kontua getKontu() {
		return kontu;
	}

	public void setKontu(Kontua kontu) {
		this.kontu = kontu;
	}

	public Dibisa getDib() {
		return dib;
	}

	public void setDib(Dibisa dib) {
		this.dib = dib;
	}

	@Override
	public String toString() {
		return "Eragiketa [mota=" + mota + ", kopurua=" + kopurua + ", dibisa eta sukurtsala=" + dibisa_sukur + ", kontu=" + kontu + ", dib="
				+ dib + "]";
	}
	
	
}
