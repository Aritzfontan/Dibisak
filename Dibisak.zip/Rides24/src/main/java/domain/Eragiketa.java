package domain;
import java.io.Serializable;

import javax.persistence.*;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class Eragiketa implements Serializable{
	private static final long serialVersionUID = 1L;
	private String mota;
	private double kopurua;
	@XmlID
	@Id
	private String dibisa_sukur;
	
	@XmlIDREF
	@ManyToOne
	private Kontua kontu;
	
	@XmlIDREF
	@ManyToOne
	private Dibisa dib;
	
	public Eragiketa(String mota, double kopurua, String dibsuk) {
		this.mota = mota;
		this.kopurua = kopurua;
		this.dibisa_sukur = dibsuk;
	}
	
	public Eragiketa() {
		super();
	}

	public String getMota() {
		return mota;
	}

	public void setMota(String mota) {
		this.mota = mota;
	}

	public double getKopurua() {
		return kopurua;
	}

	public void setKopurua(double kopurua) {
		this.kopurua = kopurua;
	}

	public Kontua getKontu() {
		return kontu;
	}

	public void setKontu(Kontua kontu) {
		this.kontu = kontu;
	}

	public Dibisa getDib() {
		return dib;
	}

	public void setDib(Dibisa dib) {
		this.dib = dib;
	}

	@Override
	public String toString() {
		return "Eragiketa [mota=" + mota + ", kopurua=" + kopurua + ", dibisa eta sukurtsala=" + dibisa_sukur + ", kontu=" + kontu + ", dib="
				+ dib + "]";
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getDibisa_sukur() {
		return dibisa_sukur;
	}

	public void setDibisa_sukur(String dibisa_sukur) {
		this.dibisa_sukur = dibisa_sukur;
	}
	
	
}
