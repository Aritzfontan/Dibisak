package domain;
import java.io.Serializable;
import java.util.*;
import javax.persistence.*;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class Dibisa implements Serializable{
	private static final long serialVersionUID = 1L;
	@XmlID
	@Id
	private String kodea;
	private double trukeBalio;
	
	@OneToMany(mappedBy = "dib")
	private List<Eragiketa> eragiketak = new Vector<Eragiketa>();
	
	@OneToMany(mappedBy = "dib", cascade = CascadeType.PERSIST)
	private List<SukurtsalekoDibisa> sukDibisak = new Vector<SukurtsalekoDibisa>();
	
	public Dibisa(String kodea, double trukeBalio) {
		this.kodea = kodea;
		this.trukeBalio = trukeBalio;
	}
	
	public Dibisa() {
		super();
	}

	public String getKodea() {
		return kodea;
	}

	public void setKodea(String kodea) {
		this.kodea = kodea;
	}

	public double getTrukeBalio() {
		return trukeBalio;
	}

	public void setTrukeBalio(double trukeBalio) {
		this.trukeBalio = trukeBalio;
	}

	public List<SukurtsalekoDibisa> getSukDibisak() {
		return sukDibisak;
	}

	public void setSukDibisak(List<SukurtsalekoDibisa> sukDibisak) {
		this.sukDibisak = sukDibisak;
	}
	
	public void addSukDibisa(SukurtsalekoDibisa sukD) {
		if (!this.sukDibisak.contains(sukD)) {
			this.sukDibisak.add(sukD);
			sukD.setDib(this);
		}
	}


	public List<Eragiketa> getEragiketak() {
		return eragiketak;
	}

	public void setEragiketak(List<Eragiketa> eragiketak) {
		this.eragiketak = eragiketak;
	}
	public void addEragiketa(Eragiketa e) {
		if (!this.eragiketak.contains(e)) {
			this.eragiketak.add(e);
			e.setDib(this);
		}
	}
	@Override
	public String toString() {
		return this.kodea;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
