package domain;
import java.io.Serializable;
import java.util.*;
import javax.persistence.*;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class Bezero implements Serializable{
	private static final long serialVersionUID = 1L;
	private String izena;
	@XmlID
	@Id
	private String na;
	@OneToMany(mappedBy = "bez", cascade = CascadeType.PERSIST)
	private List<Kontua> kontuak = new Vector<Kontua>();
	
	public Bezero(String izena, String na) {
		this.izena = izena;
		this.na = na;
	}
	
	public Bezero() {
		super();
	}

	public String getIzena() {
		return izena;
	}

	public void setIzena(String izena) {
		this.izena = izena;
	}

	public String getNa() {
		return na;
	}

	public void setNa(String na) {
		this.na = na;
	}

	public List<Kontua> getKontuak() {
		return kontuak;
	}

	public void setKontuak(List<Kontua> kontuak) {
		this.kontuak = kontuak;
	}
	public void addKontua(Kontua k) {
		if (!this.kontuak.contains(k)) {
			this.kontuak.add(k);
			k.setBez(this);
		}
		
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	
	
}