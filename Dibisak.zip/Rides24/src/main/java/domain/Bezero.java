package domain;
import java.util.*;
import javax.persistence.*;

@Entity
public class Bezero {
	private String izena;
	@Id
	private int na;
	@OneToMany(mappedBy = "bez", cascade = CascadeType.PERSIST)
	private List<Kontua> kontuak = new Vector<Kontua>();
	
	public Bezero(String izena, int na) {
		this.izena = izena;
		this.na = na;
	}

	public String getIzena() {
		return izena;
	}

	public void setIzena(String izena) {
		this.izena = izena;
	}

	public int getNa() {
		return na;
	}

	public void setNa(int na) {
		this.na = na;
	}

	public List<Kontua> getKontuak() {
		return kontuak;
	}

	public void setKontuak(List<Kontua> kontuak) {
		this.kontuak = kontuak;
	}
	public void addKontua(Kontua k) {
		if (!this.kontuak.contains(k)) {
			this.kontuak.add(k);
			k.setBez(this);
		}
		
	}

	
	
	
	
}