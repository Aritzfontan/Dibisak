package domain;
import java.io.Serializable;
import java.util.*;
import javax.persistence.*;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class Kontua implements Serializable{
	private static final long serialVersionUID = 1L;
	private double saldoa;
	@XmlID
	@Id
	private String id;
	private String bankua;
	
	@XmlIDREF
	@ManyToOne
	private Bezero bez;
	@OneToMany(mappedBy = "kontu")
	private List<Eragiketa> eragiketak = new Vector<Eragiketa>();
	
	public Kontua(double saldoa, String bankua, String id) {
		this.saldoa = saldoa;
		this.id = id;
		this.bankua = bankua;
	}
	
	public Kontua() {
		super();
	}

	public double getSaldoa() {
		return saldoa;
	}

	public void setSaldoa(double saldoa) {
		this.saldoa = saldoa;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Bezero getBez() {
		return bez;
	}

	public void setBez(Bezero bez) {
	    this.bez = bez;
	}

	public List<Eragiketa> getEragiketak() {
		return eragiketak;
	}

	public void setEragiketak(List<Eragiketa> eragiketak) {
		this.eragiketak = eragiketak;
	}
	public void addEragiketa(Eragiketa e) {
		if (!this.eragiketak.contains(e)) {
			this.eragiketak.add(e);
			e.setKontu(this);
		}
	}
	
	public boolean diruaKendu(double kop) {
		if(kop > this.saldoa) {
			return false;
		}else {
			this.saldoa -= kop;
			return true;
		}
	}
	public void diruaGehitu(double kop) {
		this.saldoa += kop;
	}
	
	public String toString() {
		return this.id;
	}

	public String getBankua() {
		return bankua;
	}

	public void setBankua(String bankua) {
		this.bankua = bankua;
	}

	public void inprimatu() {
		System.out.println("Hau da kontuaren id-a: " + ", " + this.id + "bankua: " + " " + this.bankua + ", " + "saldoa: " + this.saldoa);
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
