package dataAccess;

import java.io.File;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.persistence.*;

import configuration.ConfigXML;
import domain.*;

/**
 * It implements the data access to the objectDb database
 */
public class DataAccess  {
	private  EntityManager  db;
	private  EntityManagerFactory emf;


	ConfigXML c=ConfigXML.getInstance();

     public DataAccess()  {
		if (c.isDatabaseInitialized()) {
			String fileName=c.getDbFilename();

			File fileToDelete= new File(fileName);
			if(fileToDelete.delete()){
				File fileToDeleteTemp= new File(fileName+"$");
				fileToDeleteTemp.delete();

				  System.out.println("File deleted");
				} else {
				  System.out.println("Operation failed");
				}
		}
		open();
		if  (c.isDatabaseInitialized())initializeDB();
		
		System.out.println("DataAccess created => isDatabaseLocal: "+c.isDatabaseLocal()+" isDatabaseInitialized: "+c.isDatabaseInitialized());

		close();

	}
     
    public DataAccess(EntityManager db) {
    	this.db=db;
    }

	
	
	/**
	 * This is the data access method that initializes the database with some events and questions.
	 * This method is invoked by the business logic (constructor of BLFacadeImplementation) when the option "initialize" is declared in the tag dataBaseOpenMode of resources/config.xml file
	 */	
	public void initializeDB(){
		
		db.getTransaction().begin();

		try {
			
			Bezero bez1 = new Bezero("Ana Leza", 72600890);
			Bezero bez2 = new Bezero("Irati Lasa", 72600891);
			Bezero bez3 = new Bezero("Markel Ortega", 72600892);

			
			bez1.addKontua(new Kontua(12500, "Kutxabank", "Ana_Kutxa"));
			bez1.addKontua(new Kontua(2300, "Sabadell", "Ana_Sabadell"));
			bez1.addKontua(new Kontua(540, "BBVA", "Ana_bbva"));
			
			bez2.addKontua(new Kontua(700, "Laboral", "Irati_Laboral"));
			bez2.addKontua(new Kontua(1250, "Caixa", "Irati_Caixa"));
			
			bez3.addKontua(new Kontua(2700, "Kutxabank", "Markel_Kutxa"));
			bez3.addKontua(new Kontua(43000, "Santander", "Markel_Santander"));
			
			Dibisa dolar = new Dibisa("usd", 1.125);
			Dibisa libra = new Dibisa("gbp", 0.845);
			Dibisa yen = new Dibisa("jpy", 163.57);
			Dibisa franko = new Dibisa("chf", 0.935);
			
			Sukurtsala suk1 = new Sukurtsala("Loiu");
			Sukurtsala suk2 = new Sukurtsala("Garbera");
			Sukurtsala suk3 = new Sukurtsala("Atocha");
			
			SukurtsalekoDibisa dolar1 = new SukurtsalekoDibisa(0.05, 11000, "Loiu_usd");
			SukurtsalekoDibisa dolar2 = new SukurtsalekoDibisa(0.01, 2300, "Garbera_usd");
			SukurtsalekoDibisa dolar3 = new SukurtsalekoDibisa(0.03, 6500, "Atocha_usd");
			
			SukurtsalekoDibisa libra1 = new SukurtsalekoDibisa(0.04, 8000, "Loiu_libra");
			SukurtsalekoDibisa libra2 = new SukurtsalekoDibisa(0.005, 1200, "Garbera_libra");
			SukurtsalekoDibisa libra3 = new SukurtsalekoDibisa(0.015, 2200, "Atocha_libra");
			
			SukurtsalekoDibisa yen1 = new SukurtsalekoDibisa(0.025, 40000, "Loiu_yen");
			SukurtsalekoDibisa yen2 = new SukurtsalekoDibisa(0.01, 50000, "Garbera_yen");
			SukurtsalekoDibisa yen3 = new SukurtsalekoDibisa(0.02, 42000, "Atocha_yen");
			
			SukurtsalekoDibisa franko1 = new SukurtsalekoDibisa(0.03, 7000, "Loiu_franko");
			SukurtsalekoDibisa franko2 = new SukurtsalekoDibisa(0.01, 450, "Garbera_franko");
			SukurtsalekoDibisa franko3 = new SukurtsalekoDibisa(0.02, 2300, "Atocha_franko");
			
			suk1.addSukurtsalekoDibisa(dolar1);
			suk1.addSukurtsalekoDibisa(libra1);
			suk1.addSukurtsalekoDibisa(yen1);
			suk1.addSukurtsalekoDibisa(franko1);
			
			suk2.addSukurtsalekoDibisa(dolar2);
			suk2.addSukurtsalekoDibisa(libra2);
			suk2.addSukurtsalekoDibisa(yen2);
			suk2.addSukurtsalekoDibisa(franko2);
			
			suk3.addSukurtsalekoDibisa(dolar3);
			suk3.addSukurtsalekoDibisa(libra3);
			suk3.addSukurtsalekoDibisa(yen3);
			suk3.addSukurtsalekoDibisa(franko3);
			
			dolar.addSukDibisa(dolar1);
			dolar.addSukDibisa(dolar2);
			dolar.addSukDibisa(dolar3);
			
			libra.addSukDibisa(libra1);
			libra.addSukDibisa(libra2);
			libra.addSukDibisa(libra3);
			
			yen.addSukDibisa(yen1);
			yen.addSukDibisa(yen2);
			yen.addSukDibisa(yen3);
			
			franko.addSukDibisa(franko1);
			franko.addSukDibisa(franko2);
			franko.addSukDibisa(franko3);
			
			db.persist(bez1);
			db.persist(bez2);
			db.persist(bez3);
			db.persist(suk1);
			db.persist(suk2);
			db.persist(suk3);
			db.persist(dolar);
			db.persist(libra);
			db.persist(yen);
			db.persist(franko);
	
			db.getTransaction().commit();
			
			System.out.println("Db initialized");
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}
	

	public List<Kontua> getAccountsByNa(String na) {
		System.out.println(">> DataAccess: getAccounts=> from= " + na);
		List<Kontua> kontuak = new Vector<Kontua>();
		db.getTransaction().begin();
		Bezero bez = db.find(Bezero.class, Integer.parseInt(na));
		if(bez != null) {
			kontuak = bez.getKontuak();
		}else {
			System.out.println("Bezero hori ez dago datu basean.");
		}
		db.getTransaction().commit();
		
		return kontuak;
	}
	
	public SukurtsalekoDibisa getSukDibFromDibAndSuk(Dibisa dibisa, Sukurtsala sukurtsala) {
		try {
			TypedQuery<SukurtsalekoDibisa> query = db.createQuery("SELECT sd FROM SukurtsalekoDibisa sd WHERE sd.dib = :dibisa AND sd.suk = :sukurtsala", SukurtsalekoDibisa.class);
			query.setParameter("dibisa", dibisa);
			query.setParameter("sukurtsala", sukurtsala);
			return query.getSingleResult();
		}catch(NoResultException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public void diruaGehitu(Kontua k, double zenbat, Dibisa dib, SukurtsalekoDibisa sukD) {
		double truke = dib.getTrukeBalio();
		double komi = sukD.getKomisio();
		double kop = (zenbat/truke) + ((zenbat/truke) * komi);
		k.diruaGehitu(kop);
		Eragiketa e = new Eragiketa("Saldu", kop, dib.getKodea());
		try {
			db.getTransaction().begin();
			db.persist(e);
		    k.addEragiketa(e);
		    dib.addEragiketa(e);
		    db.merge(k); 
			db.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			if (db.getTransaction().isActive()) {
			    db.getTransaction().rollback();
			}
		}
	}
	
	public boolean diruaKendu(Kontua k, double zenbat, Dibisa dib, SukurtsalekoDibisa sukD) {
		double stock = sukD.getStock();
		double truke = dib.getTrukeBalio();
		double komi = sukD.getKomisio();
		double kop = (zenbat/truke) + ((zenbat/truke) * komi);
				
		try {
			db.getTransaction().begin();
			if (zenbat > stock) {
				db.getTransaction().rollback();
				return false;
			}
			boolean b = k.diruaKendu(kop);
			if(!b) {
				db.getTransaction().rollback();
				return false;
			}
			Eragiketa e = new Eragiketa("Erosi", kop, sukD.getId());
			db.persist(e);
			k.addEragiketa(e);
			dib.addEragiketa(e);
			db.merge(k); 
			db.merge(sukD);
			db.getTransaction().commit();
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			if (db.getTransaction().isActive()) db.getTransaction().rollback();
			return false;
		}
	}
	
	public List<Sukurtsala> getAllBranches() {
	    TypedQuery<Sukurtsala> query = db.createQuery("SELECT s FROM Sukurtsala s", Sukurtsala.class);
	    return query.getResultList();
	}
	
	public List<Dibisa> getAllCurrencies() {
	    TypedQuery<Dibisa> query = db.createQuery("SELECT dib FROM Dibisa dib", Dibisa.class);
	    return query.getResultList();
	}
	
	public String getInfoAccounts(String na) {
		StringBuilder sb = new StringBuilder();
		List<Kontua> kontuak = this.getAccountsByNa(na);
		if(kontuak.isEmpty()) return "Ez du konturik";
		for(Kontua kontu : kontuak) {
			sb.append("Kontua: ").append(kontu.getId()).append(", Saldoa: ").append(kontu.getSaldoa()).append("\n");
		}
		return sb.toString();
	}
	public String getCustomerName(String na) {
		db.getTransaction().begin();
		Bezero bez = db.find(Bezero.class, Integer.parseInt(na));
		String emaitza;
		
		if(bez != null) emaitza =  bez.getIzena();
		else emaitza = "Bezeroa ez da existitzen.";
		
		db.getTransaction().commit();
		return emaitza;		
	}


public void open(){
		
		String fileName=c.getDbFilename();
		if (c.isDatabaseLocal()) {
			emf = Persistence.createEntityManagerFactory("objectdb:"+fileName);
			db = emf.createEntityManager();
		} else {
			Map<String, String> properties = new HashMap<>();
			  properties.put("javax.persistence.jdbc.user", c.getUser());
			  properties.put("javax.persistence.jdbc.password", c.getPassword());

			  emf = Persistence.createEntityManagerFactory("objectdb://"+c.getDatabaseNode()+":"+c.getDatabasePort()+"/"+fileName, properties);
			  db = emf.createEntityManager();
    	   }
		System.out.println("DataAccess opened => isDatabaseLocal: "+c.isDatabaseLocal());

		
	}

	public void close(){
		db.close();
		System.out.println("DataAcess closed");
	}
	
}
